#include<iostream>
#include<fstream>
#include<string>
using namespace std; 
 int main()
 {
 	int sum[129];
 	string prov[129],place[129];
 	
 	ifstream srcFile("yq_in.txt",ios::in);
 	if(!srcFile)
	 {
	 	cout<<"error opening source file."<<endl;
	 	return 0;
	 }
	 
	 ofstream destFile("yq_out.txt",ios::trunc);
	 if(!destFile)
	 {
	 	srcFile.close();
	 	cout<<"error opening destination file."<<endl;
	 	return 0;
	 }
	int i;
	for(i = 0 ; i < 129 ; i++)
	{
		srcFile >> prov[i] >> place[i] >> sum[i];
	}
	string s = prov[0];
	int f = 0;
	for(i = 0 ; i < 129 ; i++)
	{
		if(prov[i] == s && f == 0){
			destFile << prov[i] <<endl;
			f = 1;
			destFile << place[i] << "	" << sum[i] <<endl;
		}
		else if(prov[i] == s && f == 1){
			destFile << place[i] << "	" << sum[i] <<endl;
		}
		else if(prov[i] != s){
			s = prov[i];
			destFile << endl;
			destFile << prov[i] <<endl;
			destFile << place[i] << "	" << sum[i] <<endl;
		}
	}
		 
		 destFile.close();
		 srcFile.close();
		 return 0;
 	
 }